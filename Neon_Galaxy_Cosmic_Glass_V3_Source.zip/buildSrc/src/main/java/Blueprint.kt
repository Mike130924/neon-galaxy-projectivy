@file:Suppress("unused")

object Blueprint {
    const val appId = "uk.neongalaxy.projectivy"
    const val version = 3
    const val versionName = "1.2.0"
}
