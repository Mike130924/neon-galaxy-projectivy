package dev.jahir.blueprint.ui.fragments

import android.Manifest
import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.graphics.drawable.Drawable
import android.os.Bundle
import android.view.View
import androidx.annotation.IdRes
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.GridLayoutManager
import com.fondesa.kpermissions.PermissionStatus
import com.fondesa.kpermissions.extension.permissionsBuilder
import com.google.android.material.snackbar.Snackbar
import dev.jahir.blueprint.R
import dev.jahir.blueprint.data.listeners.HomeItemsListener
import dev.jahir.blueprint.data.models.Counter
import dev.jahir.blueprint.data.models.HomeItem
import dev.jahir.blueprint.data.models.Icon
import dev.jahir.blueprint.data.models.IconsCounter
import dev.jahir.blueprint.data.models.KustomCounter
import dev.jahir.blueprint.data.models.WallpapersCounter
import dev.jahir.blueprint.extensions.defaultLauncher
import dev.jahir.blueprint.ui.activities.BlueprintActivity
import dev.jahir.blueprint.ui.activities.BlueprintKuperActivity
import dev.jahir.blueprint.ui.adapters.HomeAdapter
import dev.jahir.blueprint.ui.decorations.HomeGridSpacingItemDecoration
import dev.jahir.frames.data.listeners.BasePermissionRequestListener
import dev.jahir.frames.extensions.context.boolean
import dev.jahir.frames.extensions.context.drawable
import dev.jahir.frames.extensions.context.getAppName
import dev.jahir.frames.extensions.context.integer
import dev.jahir.frames.extensions.context.openLink
import dev.jahir.frames.extensions.context.string
import dev.jahir.frames.extensions.context.toast
import dev.jahir.frames.extensions.fragments.string
import dev.jahir.frames.extensions.resources.dpToPx
import dev.jahir.frames.extensions.views.setPaddingBottom
import dev.jahir.frames.extensions.views.snackbar
import dev.jahir.frames.ui.activities.base.BaseBillingActivity
import dev.jahir.frames.ui.activities.base.BaseLicenseCheckerActivity.Companion.PLAY_STORE_LINK_PREFIX
import dev.jahir.frames.ui.activities.base.BasePermissionsRequestActivity
import dev.jahir.frames.ui.activities.base.BaseSystemUIVisibilityActivity
import dev.jahir.frames.ui.widgets.StatefulRecyclerView
import dev.jahir.kuper.extensions.userWallpaper

@SuppressLint("MissingPermission")
class HomeFragment : Fragment(R.layout.fragment_home), HomeItemsListener {

    private val wallpaper: Drawable?
        get() = activity?.userWallpaper

    private val staticWallpaper: Drawable?
        get() = activity?.let {
            try {
                it.drawable(it.string(R.string.static_icons_preview_picture))
            } catch (e: Exception) {
                null
            }
        }

    private val rightWallpaper: Drawable?
        get() = activity?.let {
            if (it.boolean(R.bool.static_icons_preview_picture_by_default))
                staticWallpaper ?: wallpaper
            else wallpaper ?: staticWallpaper
        }

    private val adapter: HomeAdapter by lazy {
        HomeAdapter(
            context?.integer(R.integer.home_actions_style, 1) ?: 1,
            context?.boolean(R.bool.show_overview, true) == true,
            context?.boolean(R.bool.show_menu_in_home_page, false) == true,
            this
        )
    }

    private var recyclerView: StatefulRecyclerView? = null

    private val fabHeight: Int
        get() {
            (activity as? BlueprintActivity)?.let {
                return if (it.initialItemId == R.id.home && it.defaultLauncher != null)
                    it.fabBtn?.measuredHeight ?: 0
                else 0
            } ?: return 0
        }

    private val extraHeight: Int
        get() = if (fabHeight > 0) 16.dpToPx else 0

    private fun requestStoragePermission() {
        permissionsBuilder(Manifest.permission.READ_EXTERNAL_STORAGE)
            .build()
            .apply {
                addListener(object : BasePermissionRequestListener {
                    override fun onPermissionsGranted(result: List<PermissionStatus>) {
                        super.onPermissionsGranted(result)
                        adapter.wallpaper = wallpaper
                    }

                    override fun onPermissionsShouldShowRationale(result: List<PermissionStatus>) {
                        super.onPermissionsShouldShowRationale(result)
                        showPermissionRationale()
                    }
                })
            }
            .send()
    }

    private fun showPermissionRationale() {
        snackbar(
            string(dev.jahir.frames.R.string.permission_request, context?.getAppName()),
            Snackbar.LENGTH_INDEFINITE,
            (activity as? BasePermissionsRequestActivity<*>)?.snackbarAnchorId ?: 0
        ) {
            setAction(android.R.string.ok) {
                requestStoragePermission()
                dismiss()
            }
        }
    }

    override fun onAttach(context: Context) {
        super.onAttach(context)
        setupContentBottomOffset()
        requestStoragePermission()
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        recyclerView = view.findViewById(R.id.recycler_view)
        setupContentBottomOffset(view)
        recyclerView?.loading = false
        recyclerView?.setFastScrollEnabled(false)
        val columnsCount = 2
        val layoutManager =
            GridLayoutManager(context, columnsCount, GridLayoutManager.VERTICAL, false)
        recyclerView?.layoutManager = layoutManager

        adapter.setLayoutManager(layoutManager)
        adapter.wallpaper = rightWallpaper
        adapter.actionsStyle = context?.integer(R.integer.home_actions_style, 1) ?: 1
        adapter.showOverview = context?.boolean(R.bool.show_overview, true) == true
        adapter.showMenu = context?.boolean(R.bool.show_menu_in_home_page, false) == true
        recyclerView?.adapter = adapter
        recyclerView?.addItemDecoration(HomeGridSpacingItemDecoration(columnsCount, 8.dpToPx))
        (activity as? BlueprintActivity)?.repostCounters()
    }

    internal fun setupContentBottomOffset(view: View? = null) {
        (view ?: getView())?.let { v ->
            v.post {
                val bottomNavigationHeight =
                    (context as? BaseSystemUIVisibilityActivity<*>)?.bottomNavigation?.measuredHeight
                        ?: 0
                v.setPaddingBottom(bottomNavigationHeight + fabHeight + extraHeight)
            }
        }
    }

    @SuppressLint("NotifyDataSetChanged")
    internal fun notifyShapeChange() {
        adapter.notifyDataSetChanged()
        setupContentBottomOffset()
    }

    internal fun updateIconsPreview(icons: List<Icon>) {
        adapter.iconsPreviewList = ArrayList(icons)
        setupContentBottomOffset()
    }

    internal fun updateHomeItems(items: List<HomeItem>) {
        adapter.homeItems = ArrayList(items)
        setupContentBottomOffset()
    }

    internal fun updateWallpaper() {
        adapter.wallpaper = rightWallpaper
        setupContentBottomOffset()
    }

    internal fun updateIconsCount(count: Int) {
        adapter.iconsCount = count
        setupContentBottomOffset()
    }

    internal fun updateWallpapersCount(count: Int) {
        adapter.wallpapersCount = count
        setupContentBottomOffset()
    }

    internal fun updateKustomCount(count: Int) {
        adapter.kustomCount = count
        setupContentBottomOffset()
    }

    override fun onIconsPreviewClicked() {
        super.onIconsPreviewClicked()
        (activity as? BlueprintActivity)?.loadPreviewIcons(true)
    }

    override fun onCounterClicked(counter: Counter) {
        super.onCounterClicked(counter)
        when (counter) {
            is IconsCounter -> {
                (activity as? BlueprintActivity)?.selectNavigationItem(R.id.icons)
            }

            is WallpapersCounter -> {
                (activity as? BlueprintActivity)?.selectNavigationItem(R.id.wallpapers)
            }

            is KustomCounter -> {
                (activity as? BlueprintActivity)?.let {
                    it.startActivity(Intent(it, BlueprintKuperActivity::class.java))
                }
            }
        }
    }

    override fun onAppLinkClicked(url: String, intent: Intent?) {
        super.onAppLinkClicked(url, intent)
        intent?.let { activity?.startActivity(it) } ?: context?.openLink(url)
    }

    internal fun showDonation(show: Boolean) {
        adapter.showDonateButton = show
    }

    override fun onShareClicked() {
        try {
            val intent = Intent(Intent.ACTION_SEND).apply {
                type = "text/plain"
                putExtra(
                    Intent.EXTRA_TEXT,
                    context?.string(
                        R.string.share_text,
                        context?.getAppName(),
                        PLAY_STORE_LINK_PREFIX + context?.packageName.orEmpty()
                    )
                )
            }
            context?.startActivity(
                Intent.createChooser(
                    intent,
                    context?.string(R.string.share).orEmpty()
                )
            )
        } catch (e: Exception) {
            context?.toast(dev.jahir.frames.R.string.error)
        }
    }

    override fun onDonateClicked() {
        (activity as? BaseBillingActivity<*>)?.showDonationsDialog()
    }

    override fun onMenuItemClicked(@IdRes menuItemId: Int) {
        (activity as? BlueprintActivity)?.clickMenuItem(menuItemId)
    }

    companion object {
        const val TAG = "home_fragment"
    }
}
