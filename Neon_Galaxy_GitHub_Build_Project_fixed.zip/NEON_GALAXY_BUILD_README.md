# Neon Galaxy Projectivy Icon Pack — cloud build

This is a first installable-project pass based on the Blueprint dashboard framework. It includes the first 29 PNG icon concepts and a Projectivy icon-picker intent. The icons are initial neon concept tiles, not final faithful redraws of every app's official logo.

## Build on GitHub (no PC / Android Studio required)
1. Create a **private** GitHub repository named `neon-galaxy-projectivy`.
2. Upload the *contents* of this folder (the files inside `Blueprint-master`, not the outer folder) to the repository root.
3. Open the repository's **Actions** tab and allow workflows if GitHub asks.
4. Select **Build Neon Galaxy APK** and press **Run workflow** (or wait for the first push build).
5. When the run completes, open it and download the `Neon-Galaxy-Projectivy-APK` artifact.
6. Extract the ZIP; the APK inside is the installable debug build.

The APK is debug-signed for personal installation. This workflow does not publish or release anything.

## Important
- The dashboard advertises the Projectivy icon-picker action. Actual icon selection and compatibility must be tested on the Sony BRAVIA 7.
- This initial package has 29 concept icons. The next artwork pass should replace the placeholder-like concepts with recognisable, carefully redrawn neon versions of the real app logos.
- No activity-specific automatic mappings have been asserted yet; use Projectivy's icon picker to assign the icons.
- Blueprint is licensed CC BY-SA 4.0; retain its licence and attribution when redistributing modified work.
