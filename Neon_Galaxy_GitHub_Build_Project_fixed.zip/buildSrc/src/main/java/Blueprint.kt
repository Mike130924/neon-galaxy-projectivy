@file:Suppress("unused")

object Blueprint {
    const val appId = "uk.neongalaxy.projectivy"
    const val version = 1
    const val versionName = "1.0.0"
}
