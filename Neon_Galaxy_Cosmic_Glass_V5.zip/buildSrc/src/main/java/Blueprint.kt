@file:Suppress("unused")

object Blueprint {
    const val appId = "uk.neongalaxy.projectivy"
    const val version = 4
    const val versionName = "1.3.0"
}
